import product from './product'


export default {
    //产品列表接口
    ...product,

}
